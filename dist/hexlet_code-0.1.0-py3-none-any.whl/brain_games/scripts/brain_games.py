#!/usr/bin/env python3.


from brain_games.scripts.brain_even import *
from brain_games.scripts.brain_even import parity_of_numbers


def main():
    print('Welcome to the Brain Games!')
    parity_of_numbers()


if __name__ == '__main__':
    main()
